package com.jarvis.assistant.actions

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Hava durumu — orijinal actions/weather.py ile aynı servisi (wttr.in) kullanır.
 * Platforma bağlı olmayan bir HTTP isteği olduğu için neredeyse birebir taşındı.
 */
object Weather {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    fun getSummary(location: String?): String {
        val target = location?.trim()?.ifBlank { null } ?: "Istanbul"

        val request = Request.Builder()
            .url("https://wttr.in/$target?format=j1")
            .header("User-Agent", "JARVIS Android")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return "Hava durumu bilgisi şu anda alınamadı."
                val body = response.body?.string() ?: return "Hava durumu bilgisi şu anda alınamadı."
                parse(target, body)
            }
        } catch (e: Exception) {
            "Hava durumu bilgisi şu anda alınamadı."
        }
    }

    private fun parse(target: String, raw: String): String {
        return try {
            val json = JSONObject(raw)
            val current = json.getJSONArray("current_condition").getJSONObject(0)
            val tempC = current.optString("temp_C", "")
            val feelsLike = current.optString("FeelsLikeC", "")
            val humidity = current.optString("humidity", "")
            val desc = current.getJSONArray("weatherDesc").getJSONObject(0).optString("value", "")

            val parts = mutableListOf<String>()
            if (tempC.isNotBlank()) parts.add("$tempC derece")
            if (desc.isNotBlank()) parts.add(desc.lowercase())
            if (feelsLike.isNotBlank() && feelsLike != tempC) parts.add("hissedilen $feelsLike derece")
            if (humidity.isNotBlank()) parts.add("nem yüzde $humidity")

            if (parts.isEmpty()) "Hava durumu bilgisi şu anda alınamadı."
            else "$target için hava durumu: " + parts.joinToString(", ") + "."
        } catch (e: Exception) {
            "Hava durumu bilgisi şu anda alınamadı."
        }
    }
}

package com.jarvis.assistant.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini API istemcisi.
 *
 * Orijinal Windows sürümü `google-genai` Python paketini kullanıyordu.
 * Android'de resmi bir Kotlin SDK olmadığı / ek bağımlılık şişirmemek için
 * doğrudan REST endpoint'ine OkHttp ile istek atıyoruz. Fonksiyon çağırma
 * (tool calling) mantığı aynı: model "function_call" döndürürse, ilgili
 * Kotlin fonksiyonunu çalıştırıp sonucu tekrar modele yolluyoruz.
 */
class GeminiClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val model = "gemini-2.0-flash"
    private val endpoint: String
        get() = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

    data class ToolCall(val name: String, val args: JSONObject)

    sealed class GeminiResponse {
        data class Text(val text: String) : GeminiResponse()
        data class FunctionCall(val call: ToolCall) : GeminiResponse()
        data class Error(val message: String) : GeminiResponse()
    }

    /**
     * Tek seferlik istek gönderir. history: önceki mesajlar (role + parts),
     * tools: fonksiyon tanımları (JSON şemasıyla).
     */
    fun sendMessage(history: JSONArray, tools: JSONArray?): GeminiResponse {
        val body = JSONObject().apply {
            put("contents", history)
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", SystemPrompt.TEXT)))
            })
            if (tools != null) {
                put("tools", JSONArray().put(JSONObject().put("function_declarations", tools)))
            }
        }

        val request = Request.Builder()
            .url(endpoint)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return GeminiResponse.Error("API hatası (${response.code}): $raw")
                }
                parseResponse(raw)
            }
        } catch (e: Exception) {
            GeminiResponse.Error("Bağlantı hatası: ${e.message}")
        }
    }

    private fun parseResponse(raw: String): GeminiResponse {
        return try {
            val json = JSONObject(raw)
            val candidate = json.getJSONArray("candidates").getJSONObject(0)
            val parts = candidate.getJSONObject("content").getJSONArray("parts")
            val firstPart = parts.getJSONObject(0)

            if (firstPart.has("functionCall")) {
                val fc = firstPart.getJSONObject("functionCall")
                val name = fc.getString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                GeminiResponse.FunctionCall(ToolCall(name, args))
            } else {
                val text = firstPart.optString("text", "")
                GeminiResponse.Text(text)
            }
        } catch (e: Exception) {
            GeminiResponse.Error("Cevap işlenemedi: ${e.message}")
        }
    }
}

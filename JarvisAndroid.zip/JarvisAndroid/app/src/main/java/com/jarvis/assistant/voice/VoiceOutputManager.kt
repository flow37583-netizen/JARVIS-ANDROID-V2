package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Sesli okuma (TTS) — Android sürümü.
 *
 * Orijinal Windows sürümü (actions/tts.py) PowerShell üzerinden
 * Windows'un SAPI konuşma motorunu çağırıyordu — tamamen Windows'a
 * özgüydü. Android'in kendi yerleşik TextToSpeech API'si, hiçbir
 * harici komuta ihtiyaç duymadan aynı işi (hatta daha sorunsuz) yapar.
 */
class VoiceOutputManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        val trimmed = if (text.length > 500) text.take(500) + "..." else text
        tts?.speak(trimmed, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}

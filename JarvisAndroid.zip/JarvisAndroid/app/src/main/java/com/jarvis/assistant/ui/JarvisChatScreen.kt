package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val BgDark = Color(0xFF0A0E14)
private val SurfaceDark = Color(0xFF131922)
private val AccentCyan = Color(0xFF4FD8E8)
private val UserBubble = Color(0xFF1E2733)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisChatScreen(
    messages: List<ChatMessage>,
    isLoading: Boolean,
    isListening: Boolean,
    onSendMessage: (String) -> Unit,
    onMicClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(messages.size - 1) }
        }
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = {
                    Text("JARVIS", fontWeight = FontWeight.Bold, color = AccentCyan)
                },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        bottomBar = {
            Surface(color = SurfaceDark) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onMicClick,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (isListening) AccentCyan else UserBubble)
                    ) {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = "Sesli komut",
                            tint = if (isListening) BgDark else Color.White
                        )
                    }

                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("JARVIS'e bir şey sor...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = SurfaceDark,
                            focusedContainerColor = SurfaceDark,
                            unfocusedTextColor = Color.White,
                            focusedTextColor = Color.White
                        ),
                        maxLines = 4
                    )

                    IconButton(
                        onClick = {
                            if (input.isNotBlank()) {
                                onSendMessage(input)
                                input = ""
                            }
                        },
                        enabled = !isLoading
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Gönder", tint = AccentCyan)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(messages) { msg ->
                MessageBubble(msg)
            }
            if (isLoading) {
                item {
                    Row(modifier = Modifier.padding(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AccentCyan, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("JARVIS düşünüyor...", color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.isUser) UserBubble else SurfaceDark,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = message.text,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

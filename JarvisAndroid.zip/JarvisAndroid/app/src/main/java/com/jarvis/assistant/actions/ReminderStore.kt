package com.jarvis.assistant.actions

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.reminderStore by preferencesDataStore(name = "jarvis_reminders")

/**
 * Hatırlatıcılar — Android sürümü.
 *
 * Not: Orijinal Windows sürümünde bu özellik gerçekte implement edilmemişti,
 * sadece Microsoft To-Do'yu tarayıcıda açıyordu (mac sürümü Apple Reminders
 * kullanıyordu, Windows karşılığı yoktu). Burada gerçek bir bildirim sistemi
 * kurduk: AlarmManager ile zamanlanmış, telefonun kendi bildirim ekranında
 * çıkan hatırlatıcılar. Bu yönüyle orijinal Windows sürümünden daha işlevsel.
 */
class ReminderStore(private val context: Context) {

    private val remindersKey = stringPreferencesKey("reminders_json")

    suspend fun add(title: String, dueIso: String): Reminder {
        val reminder = Reminder(
            id = System.currentTimeMillis(),
            title = title,
            dueIso = dueIso
        )
        val list = getAll().toMutableList()
        list.add(reminder)
        saveAll(list)
        ReminderScheduler.schedule(context, reminder)
        return reminder
    }

    suspend fun getAll(): List<Reminder> {
        val prefs = context.reminderStore.data.first()
        val raw = prefs[remindersKey] ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                Reminder(obj.getLong("id"), obj.getString("title"), obj.getString("dueIso"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun saveAll(list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("dueIso", r.dueIso)
            })
        }
        context.reminderStore.edit { prefs ->
            prefs[remindersKey] = arr.toString()
        }
    }

    suspend fun formatList(): String {
        val all = getAll().sortedBy { it.dueIso }
        if (all.isEmpty()) return "Kayıtlı hatırlatıcı yok."
        return all.joinToString("\n") { "- ${it.title} (${it.dueIso})" }
    }
}

data class Reminder(val id: Long, val title: String, val dueIso: String)

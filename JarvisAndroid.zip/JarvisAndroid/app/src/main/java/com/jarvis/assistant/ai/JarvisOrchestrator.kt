package com.jarvis.assistant.ai

import android.content.Context
import com.jarvis.assistant.actions.AppLauncher
import com.jarvis.assistant.actions.ReminderStore
import com.jarvis.assistant.actions.Weather
import com.jarvis.assistant.data.MemoryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * JARVIS çekirdek orkestratörü — Android sürümü.
 *
 * Orijinal Windows sürümünde main.py bu rolü üstleniyordu: kullanıcı
 * isteğini Gemini'ye gönderir, model bir araç (function call) isterse
 * ilgili Python fonksiyonunu çalıştırıp sonucu tekrar modele yollar.
 * Buradaki mantık birebir aynı — sadece araçlar Android'in güvenli
 * API'leriyle (Intent, SpeechRecognizer, AlarmManager) çalışıyor.
 */
class JarvisOrchestrator(
    private val context: Context,
    private val apiKey: String
) {
    private val gemini = GeminiClient(apiKey)
    private val memory = MemoryManager(context)
    private val reminders = ReminderStore(context)
    private val history = JSONArray()

    suspend fun processUserMessage(userText: String): String = withContext(Dispatchers.IO) {
        appendToHistory("user", userText)

        // Çağrı zincirini takip et: model art arda birden fazla araç isteyebilir
        repeat(5) {
            val response = gemini.sendMessage(history, ToolDefinitions.all())

            when (response) {
                is GeminiClient.GeminiResponse.Text -> {
                    appendToHistory("model", response.text)
                    return@withContext response.text
                }
                is GeminiClient.GeminiResponse.FunctionCall -> {
                    val result = executeTool(response.call)
                    appendFunctionCallToHistory(response.call)
                    appendFunctionResultToHistory(response.call.name, result)
                }
                is GeminiClient.GeminiResponse.Error -> {
                    return@withContext "Bir hata oluştu: ${response.message}"
                }
            }
        }
        "İsteği tamamlayamadım, tekrar dener misin?"
    }

    private suspend fun executeTool(call: GeminiClient.ToolCall): String {
        val args = call.args
        return when (call.name) {
            "open_app" -> AppLauncher.open(context, args.optString("app_name"))
            "get_weather" -> Weather.getSummary(args.optString("location", null))
            "add_reminder" -> {
                val r = reminders.add(args.optString("title"), args.optString("due_iso"))
                "Hatırlatıcı eklendi: ${r.title} (${r.dueIso})"
            }
            "get_reminders" -> reminders.formatList()
            "save_memory" -> {
                memory.saveMemory(args.optString("key"), args.optString("value"))
                "Kaydedildi."
            }
            "delete_memory" -> {
                memory.deleteMemory(args.optString("key"))
                "Silindi."
            }
            "play_media" -> AppLauncher.playMedia(context, args.optString("query"), args.optString("provider", "youtube"))
            "share_whatsapp" -> AppLauncher.shareToWhatsapp(context, args.optString("text"))
            "web_search_open" -> AppLauncher.webSearch(context, args.optString("query"))
            else -> "Bilinmeyen araç: ${call.name}"
        }
    }

    private fun appendToHistory(role: String, text: String) {
        history.put(JSONObject().apply {
            put("role", role)
            put("parts", JSONArray().put(JSONObject().put("text", text)))
        })
    }

    private fun appendFunctionCallToHistory(call: GeminiClient.ToolCall) {
        history.put(JSONObject().apply {
            put("role", "model")
            put("parts", JSONArray().put(JSONObject().apply {
                put("functionCall", JSONObject().apply {
                    put("name", call.name)
                    put("args", call.args)
                })
            }))
        })
    }

    private fun appendFunctionResultToHistory(name: String, result: String) {
        history.put(JSONObject().apply {
            put("role", "function")
            put("parts", JSONArray().put(JSONObject().apply {
                put("functionResponse", JSONObject().apply {
                    put("name", name)
                    put("response", JSONObject().put("result", result))
                })
            }))
        })
    }
}

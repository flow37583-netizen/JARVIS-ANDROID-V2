package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

/**
 * Uygulama açma — Android sürümü.
 *
 * Orijinal Windows sürümü (actions/open_app.py) `os.startfile` ve
 * Windows .exe isimleriyle çalışıyordu. Bu, Android'de doğrudan karşılığı
 * olmayan bir mantıktı. Burada Android paket adlarıyla, sistemin kendi
 * PackageManager + Intent API'siyle çalışan bir karşılığı var.
 */
object AppLauncher {

    // Yaygın uygulamalar için bilinen paket adları (orijinaldeki APP_ALIASES listesine benzer)
    private val KNOWN_PACKAGES = mapOf(
        "whatsapp" to "com.whatsapp",
        "spotify" to "com.spotify.music",
        "chrome" to "com.android.chrome",
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "haritalar" to "com.google.android.apps.maps",
        "takvim" to "com.google.android.calendar",
        "calendar" to "com.google.android.calendar",
        "telegram" to "org.telegram.messenger",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "ayarlar" to "com.android.settings",
        "settings" to "com.android.settings",
        "kamera" to "com.android.camera",
        "camera" to "com.android.camera",
        "galeri" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "fotoğraflar" to "com.google.android.apps.photos",
    )

    /**
     * Uygulamayı açmaya çalışır. Önce bilinen paket adı eşleşmesine bakar,
     * sonra cihazda kurulu uygulamalar arasında isim bazlı arama yapar.
     */
    fun open(context: Context, appName: String): String {
        if (appName.isBlank()) return "Uygulama adı belirtilmedi."

        val normalized = appName.trim().lowercase()
        val pm = context.packageManager

        // 1. Bilinen paket adı listesinden dene
        KNOWN_PACKAGES[normalized]?.let { packageName ->
            if (launchByPackage(context, pm, packageName)) {
                return "$appName açıldı."
            }
        }

        // 2. Cihazda kurulu uygulamalar arasında görünen isme göre ara
        val launchIntent = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .firstOrNull { appInfo ->
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                label.contains(normalized) || normalized.contains(label)
            }

        if (launchIntent != null) {
            if (launchByPackage(context, pm, launchIntent.packageName)) {
                return "$appName açıldı."
            }
        }

        return "'$appName' telefonda bulunamadı. Kurulu olmayan bir uygulamayı açamam."
    }

    private fun launchByPackage(context: Context, pm: PackageManager, packageName: String): Boolean {
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** YouTube veya Spotify'da arama açar (play_media karşılığı). */
    fun playMedia(context: Context, query: String, provider: String): String {
        val encoded = Uri.encode(query)
        val (uri, fallbackUrl) = when (provider.lowercase()) {
            "spotify" -> "spotify:search:$encoded" to "https://open.spotify.com/search/$encoded"
            else -> "vnd.youtube:$encoded" to "https://www.youtube.com/results?search_query=$encoded"
        }

        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "$provider üzerinde '$query' araması açıldı."
        } catch (e: Exception) {
            // Uygulama kurulu değilse tarayıcıya düş
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "$provider uygulaması bulunamadı, tarayıcıda açıldı."
            } catch (e2: Exception) {
                "Medya açılamadı: ${e2.message}"
            }
        }
    }

    /** WhatsApp'ta paylaşım ekranı açar — pyautogui otomasyonu yerine kullanıcı onaylı, güvenli yol. */
    fun shareToWhatsapp(context: Context, text: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "WhatsApp'ta mesaj hazırlandı, gönder butonuna basman yeterli."
        } catch (e: Exception) {
            "WhatsApp bulunamadı veya açılamadı."
        }
    }

    /** Tarayıcıda Google araması açar. */
    fun webSearch(context: Context, query: String): String {
        val encoded = Uri.encode(query)
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            "'$query' için arama açıldı."
        } catch (e: Exception) {
            "Arama açılamadı: ${e.message}"
        }
    }
}

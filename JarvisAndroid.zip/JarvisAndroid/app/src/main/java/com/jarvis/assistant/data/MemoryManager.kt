package com.jarvis.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONObject

private val Context.memoryStore by preferencesDataStore(name = "jarvis_memory")

/**
 * Kalıcı hafıza yöneticisi.
 *
 * Orijinal Windows sürümünde memory/memory_manager.py bir JSON dosyasına
 * (memory.json) yazıp okuyordu. Android'de dosya yerine DataStore kullanıyoruz
 * — aynı mantık (anahtar-değer kalıcı kayıt), platforma uygun depolama.
 */
class MemoryManager(private val context: Context) {

    private val memoryKey = stringPreferencesKey("memory_json")

    suspend fun loadMemory(): JSONObject {
        val prefs = context.memoryStore.data.first()
        val raw = prefs[memoryKey] ?: "{}"
        return try {
            JSONObject(raw)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    suspend fun saveMemory(key: String, value: String) {
        val current = loadMemory()
        current.put(key, value)
        context.memoryStore.edit { prefs ->
            prefs[memoryKey] = current.toString()
        }
    }

    suspend fun deleteMemory(key: String) {
        val current = loadMemory()
        current.remove(key)
        context.memoryStore.edit { prefs ->
            prefs[memoryKey] = current.toString()
        }
    }

    /** Sistem prompt'una eklemek için hafızayı okunabilir metne çevirir. */
    suspend fun formatForPrompt(): String {
        val mem = loadMemory()
        if (mem.length() == 0) return ""
        val sb = StringBuilder("\nKAYITLI BİLGİLER:\n")
        mem.keys().forEach { key ->
            sb.append("- $key: ${mem.getString(key)}\n")
        }
        return sb.toString()
    }
}

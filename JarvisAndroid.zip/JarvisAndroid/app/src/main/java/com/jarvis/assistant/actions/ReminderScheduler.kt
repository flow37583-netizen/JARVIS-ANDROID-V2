package com.jarvis.assistant.actions

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * ISO 8601 tarih/saat ile bir Android AlarmManager alarmı kurar.
 * Bildirim, alarm tetiklendiğinde ReminderReceiver tarafından gösterilir.
 */
object ReminderScheduler {

    fun schedule(context: Context, reminder: Reminder) {
        val triggerMillis = parseIso(reminder.dueIso) ?: return

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", reminder.title)
            putExtra("id", reminder.id)
        }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pendingIntent = PendingIntent.getBroadcast(context, reminder.id.toInt(), intent, flags)

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                // Kesin alarm izni yoksa, sistem zamanlamasına bırak (biraz gecikebilir)
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
        }
    }

    private fun parseIso(iso: String): Long? {
        return try {
            val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
            format.timeZone = TimeZone.getDefault()
            format.parse(iso)?.time
        } catch (e: Exception) {
            null
        }
    }
}

package com.jarvis.assistant.ui

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)

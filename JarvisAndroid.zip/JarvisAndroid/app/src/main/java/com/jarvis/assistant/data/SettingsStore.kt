package com.jarvis.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "jarvis_settings")

/**
 * Ayarlar deposu — orijinal app_config.py'nin (api_keys.json) Android karşılığı.
 * Gemini API anahtarı, dosya yerine DataStore'da saklanır.
 */
class SettingsStore(private val context: Context) {

    private val apiKeyPref = stringPreferencesKey("gemini_api_key")

    val apiKeyFlow: Flow<String> = context.settingsStore.data.map { it[apiKeyPref] ?: "" }

    suspend fun saveApiKey(key: String) {
        context.settingsStore.edit { it[apiKeyPref] = key }
    }
}

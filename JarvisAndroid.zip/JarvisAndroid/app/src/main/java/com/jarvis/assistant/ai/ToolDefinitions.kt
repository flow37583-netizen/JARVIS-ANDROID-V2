package com.jarvis.assistant.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Gemini'ye tanıtılan araçlar (function declarations).
 *
 * Orijinal Windows listesindeki shell_run, analyze_screen,
 * pyautogui tabanlı whatsapp gönderimi BURADA YOK — bilinçli olarak
 * çıkarıldı çünkü Android'in güvenlik modeliyle uyumsuzlar.
 */
object ToolDefinitions {

    fun all(): JSONArray {
        val list = JSONArray()

        list.put(simpleTool(
            name = "open_app",
            description = "Telefonda kurulu bir uygulamayı açar.",
            params = mapOf("app_name" to "Açılacak uygulamanın adı (örn. spotify, whatsapp, chrome)")
        ))

        list.put(simpleTool(
            name = "get_weather",
            description = "Belirtilen konum için güncel hava durumu özetini getirir.",
            params = mapOf("location" to "Şehir adı (örn. İstanbul)")
        ))

        list.put(simpleTool(
            name = "add_reminder",
            description = "Yeni bir anımsatıcı/hatırlatıcı ekler ve belirtilen zamanda bildirim gönderir.",
            params = mapOf(
                "title" to "Hatırlatıcı başlığı",
                "due_iso" to "ISO 8601 formatında tarih/saat (örn. 2026-06-21T09:00:00)"
            )
        ))

        list.put(simpleTool(
            name = "get_reminders",
            description = "Kayıtlı tüm anımsatıcıları listeler.",
            params = emptyMap()
        ))

        list.put(simpleTool(
            name = "save_memory",
            description = "Kullanıcı hakkında önemli, kalıcı bir bilgiyi hafızaya kaydeder.",
            params = mapOf(
                "key" to "Kısa anahtar (örn. 'favori_renk')",
                "value" to "Kaydedilecek bilgi"
            )
        ))

        list.put(simpleTool(
            name = "delete_memory",
            description = "Hafızadan bir kaydı siler.",
            params = mapOf("key" to "Silinecek kaydın anahtarı")
        ))

        list.put(simpleTool(
            name = "play_media",
            description = "YouTube veya Spotify'da arama açar; yüklüyse ilgili uygulamada, değilse tarayıcıda.",
            params = mapOf(
                "query" to "Aranacak şarkı/video",
                "provider" to "youtube veya spotify"
            )
        ))

        list.put(simpleTool(
            name = "share_whatsapp",
            description = "WhatsApp'ta gönderilecek mesajı paylaşım ekranında hazır olarak açar; gönderme işlemini kullanıcı kendisi onaylar.",
            params = mapOf("text" to "Gönderilecek mesaj metni")
        ))

        list.put(simpleTool(
            name = "web_search_open",
            description = "Tarayıcıda Google araması açar.",
            params = mapOf("query" to "Arama sorgusu")
        ))

        return list
    }

    private fun simpleTool(name: String, description: String, params: Map<String, String>): JSONObject {
        val properties = JSONObject()
        params.forEach { (key, desc) ->
            properties.put(key, JSONObject().apply {
                put("type", "string")
                put("description", desc)
            })
        }
        return JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", properties)
                if (params.isNotEmpty()) {
                    put("required", JSONArray(params.keys.toList()))
                }
            })
        }
    }
}

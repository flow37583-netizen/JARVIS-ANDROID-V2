package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.ai.JarvisOrchestrator
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.ui.ChatMessage
import com.jarvis.assistant.ui.JarvisChatScreen
import com.jarvis.assistant.ui.SettingsScreen
import com.jarvis.assistant.voice.VoiceInputManager
import com.jarvis.assistant.voice.VoiceOutputManager
import kotlinx.coroutines.launch

/**
 * Ana ekran — Android sürümünün giriş noktası.
 *
 * Orijinal Windows sürümünde main.py + ui.py (Tkinter) bu rolü
 * üstleniyordu. Burada Jetpack Compose ile native bir Android arayüzü var.
 */
class MainActivity : ComponentActivity() {

    private lateinit var settingsStore: SettingsStore
    private lateinit var voiceOutput: VoiceOutputManager
    private lateinit var voiceInput: VoiceInputManager
    private var orchestrator: JarvisOrchestrator? = null

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            // Mikrofon izni verilmezse sesli komut devre dışı kalır, metin yazma çalışmaya devam eder
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        settingsStore = SettingsStore(this)
        voiceOutput = VoiceOutputManager(this)
        voiceInput = VoiceInputManager(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            MaterialTheme {
                JarvisApp()
            }
        }
    }

    @Composable
    private fun JarvisApp() {
        var showSettings by remember { mutableStateOf(false) }
        var apiKey by remember { mutableStateOf("") }
        val messages = remember { mutableStateListOf<ChatMessage>() }
        var isLoading by remember { mutableStateOf(false) }
        var isListening by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            settingsStore.apiKeyFlow.collect { key ->
                apiKey = key
                if (key.isNotBlank() && orchestrator == null) {
                    orchestrator = JarvisOrchestrator(this@MainActivity, key)
                }
            }
        }

        if (showSettings || apiKey.isBlank()) {
            SettingsScreen(
                currentApiKey = apiKey,
                onSave = { newKey ->
                    lifecycleScope.launch {
                        settingsStore.saveApiKey(newKey)
                        orchestrator = JarvisOrchestrator(this@MainActivity, newKey)
                        showSettings = false
                    }
                },
                onBack = { if (apiKey.isNotBlank()) showSettings = false }
            )
        } else {
            JarvisChatScreen(
                messages = messages,
                isLoading = isLoading,
                isListening = isListening,
                onSendMessage = { text ->
                    messages.add(ChatMessage(text, isUser = true))
                    isLoading = true
                    lifecycleScope.launch {
                        val reply = orchestrator?.processUserMessage(text)
                            ?: "Önce ayarlardan API anahtarını gir."
                        messages.add(ChatMessage(reply, isUser = false))
                        isLoading = false
                        voiceOutput.speak(reply)
                    }
                },
                onMicClick = {
                    voiceInput.startListening(
                        onResult = { spokenText ->
                            messages.add(ChatMessage(spokenText, isUser = true))
                            isLoading = true
                            lifecycleScope.launch {
                                val reply = orchestrator?.processUserMessage(spokenText)
                                    ?: "Önce ayarlardan API anahtarını gir."
                                messages.add(ChatMessage(reply, isUser = false))
                                isLoading = false
                                voiceOutput.speak(reply)
                            }
                        },
                        onError = { errorMsg ->
                            isListening = false
                        },
                        onListeningStateChange = { listening ->
                            isListening = listening
                        }
                    )
                },
                onSettingsClick = { showSettings = true }
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceOutput.shutdown()
        voiceInput.stopListening()
    }
}

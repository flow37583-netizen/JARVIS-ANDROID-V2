# JARVIS Android — Kurulum ve Açıklama

Bu, orijinal Windows JARVIS projesinin (Alp Ünlü / @alppunlu) çekirdek mantığından
ilham alınarak Android için **sıfırdan Kotlin ile yazılmış**, kişisel kullanım
amaçlı bir sürümüdür. PC sürümünün dosyası "çevrilmedi" — Android'in kendi
güvenli API'leriyle yeniden inşa edildi.

## Bu sürümde NE VAR

- Gemini AI ile sohbet/komut işleme (function calling mimarisi orijinaliyle aynı mantıkta)
- Sesli komut (Android SpeechRecognizer)
- Sesli cevap (Android TextToSpeech)
- Kalıcı hafıza (DataStore tabanlı, orijinaldeki memory.json mantığının karşılığı)
- Hava durumu (orijinaliyle aynı wttr.in servisi)
- Hatırlatıcılar — AlarmManager + gerçek bildirim (orijinal Windows sürümünde bu
  özellik aslında implement edilmemişti, sadece tarayıcı açıyordu; burada gerçek
  çalışan bir karşılığı var)
- Uygulama açma (Android paket adlarıyla, Intent sistemiyle)
- YouTube/Spotify'da arama açma
- WhatsApp'a mesaj paylaşımı (kullanıcı onaylı, Intent.ACTION_SEND ile)
- Koyu temalı, JARVIS esintili Jetpack Compose arayüzü

## Bu sürümde BİLEREK OLMAYAN şeyler (ve neden)

- **Shell komutu çalıştırma**: Android, uygulamaların sistem genelinde rastgele
  komut çalıştırmasına izin vermiyor. Bu bir eksiklik değil, platformun güvenlik
  mimarisinin temel taşı.
- **Tüm ekranı otomatik analiz etme**: Android'de MediaProjection izniyle mümkün
  ama her seferinde kullanıcı onayı gerektiriyor, arka planda sessizce çalışamaz.
  Bilinçli olarak dahil edilmedi.
- **Klavye otomasyonuyla WhatsApp gönderimi**: Orijinal pyautogui yöntemi yerine
  güvenli paylaşım ekranı (ACTION_SEND) kullanıldı — kullanıcı son onayı kendisi verir.

## Kurulum

1. Android Studio indir ve kur (developer.android.com/studio)
2. Bu klasörü "Open an existing project" ile aç
3. Gradle senkronizasyonunun bitmesini bekle (ilk seferde internet ister)
4. Telefonunu USB ile bağla (geliştirici modu + USB hata ayıklama açık olmalı)
   veya bir emülatör başlat
5. Üstteki yeşil "Run" (▶) butonuna bas

## API Anahtarı

Uygulama ilk açıldığında senden bir Gemini API anahtarı isteyecek.
Ücretsiz anahtarı şuradan alabilirsin: aistudio.google.com/apikey

## APK olarak dışa aktarma (telefonuna kurmak için)

Android Studio'da: Build menüsü -> Build Bundle(s) / APK(s) -> Build APK(s).
Oluşan .apk dosyasını app/build/outputs/apk/debug/ klasöründe bulabilir,
telefonuna kopyalayıp kurabilirsin (telefon ayarlarından "bilinmeyen kaynaklardan
kuruluma izin ver" gerekebilir).

## Önemli not

Bu proje, Alp Ünlü'nün orijinal masaüstü JARVIS projesinden ilham alınarak
yazılmıştır ve kişisel/şahsi kullanım amaçlıdır. Yayınlamadan veya dağıtmadan
önce orijinal projenin sahibiyle iletişime geçmen önerilir.
